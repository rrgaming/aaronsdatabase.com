<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            .col-centered{
                float: none;
                margin: 0 auto;
                top: 130px;
            }
        </style>
</head>
<body>

<div class="container-fluid">
	<div class="pull-right">
        <ul class="nav nav-pills">
              @if(Auth::user())
            <li class="nav-header">{{ ucwords(Auth::user()->username) }}</li>
            <li>{{ Html::link('post', 'Add Post') }}</li>
            <li>{{ Html::link('users', 'View Users') }}</li>
            <li>{{ Html::link('logout', 'Logout') }}</li>
            @else
            <li>{{ Html::link('login', 'Login', array('class' => '')) }}</li>
            @endif
        </ul>
	</div>

    <div class="container">
        <div class="col-centered col-md-4">
            @yield('content')
        </div>
        
    </div>
</div>
</body>
</html>