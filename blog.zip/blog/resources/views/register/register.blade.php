@extends('shared.header')

@section('content')

<div class="panel panel-default">
	<div class="panel-heading">
		<h2>Register</h2>
	</div>
    <div class="panel-body">
    	{{ Form::open(array('url' => 'register')) }}

		<!-- if there are login errors, show them here -->

		<p>
		    {{ $errors->first('username') }}
		    {{ $errors->first('password') }}
		</p>
		<div class="form-group">
			{{ Form::label('username', 'Username') }}
		    {{ Form::email('username', Input::old('text'), array('placeholder' => 'Username', 'class' => 'form-control')) }}
		</div>
		 <div class="form-group">
		 	{{ Form::label('email', 'Email Address') }}
		    {{ Form::text('email', Input::old('email'), array('placeholder' => 'Email', 'class' => 'form-control')) }}
		 </div>   
		    

		<div class="form-group">
		    {{ Form::label('password', 'Password') }}
		    <input type="password" name="password" class="form-control" placeholder="Password">
		</div>

		<p>
			{{ Form::submit('Register',['class' => 'btn btn-large btn-primary']) }}
			{{ Html::link('login', 'Cancel', array('class' => 'btn btn-danger')) }}
		</p>
		{{ Form::close() }}
    </div>
</div>

@stop