@foreach ($data as $dt)
	{{ $dt->fname }}
	{{ $dt->lname }}
	<br>
@endforeach