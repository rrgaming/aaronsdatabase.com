@extends('shared.header')

@section('content')

<div class="panel panel-default">
	<div class="panel-heading">
		<h2>Login</h2>
	</div>
    <div class="panel-body">
        {{ Form::open(array('url' => 'login')) }}
		
		<!-- if there are login errors, show them here -->

		<p>
		    {{ $errors->first('username') }}
		    {{ $errors->first('password') }}
		</p>

		<div class="form-group">
		    {{ Form::label('username', 'Username') }}
		    {{ Form::text('username','',array('placeholder' => 'Username', 'class' => 'form-control')) }}
		</div>

		<div class="form-group">
		    {{ Form::label('password', 'Password') }}
		    <input type="password" name="password" class="form-control" placeholder="Password">
		</div>

		<p>
			{{ Form::submit('Submit',['class' => 'btn btn-large btn-primary']) }}
			{{ Html::link('register', 'Not yet User?')}}
		</p>
		{{ Form::close() }}
    </div>
</div>

	
@stop