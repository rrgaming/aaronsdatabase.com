<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller;

class PersonController extends Controller
{
    public function person(){
    	$data = DB::table('person')->get();

    	return view('person', ['data' => $data]);
    }
}
