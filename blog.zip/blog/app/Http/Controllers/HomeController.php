<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller;
use Validator, Input, Redirect, View;
use App;
use Auth;

class HomeController extends Controller{

	public function index(){
		
		return view('shared.header');
	}
	public function login(){

		return view ('login.login');
	}
	public function register(){
		return View::make('register.register');
	}
	public function postLogin(){
		//do input validations

		$input = Input::all();
		$rules = array(
			'username' => 'required',
			'password' => 'required|min:4'
		);
		$validator = Validator::make(Input::all(), $rules);

		if($validator->fails()){
			return Redirect::to('login')
			->withErrors($validator);
		}
		else{
			$userData = array(
				'username' => $input['username'],
				'password' => $input['password']
			);

			$auth = Auth::attempt(array(
                'username' => $input['username'],
				'password' => $input['password']
                ));

            if($auth) {
                return Redirect::route('register');
            }
            else{
            	var_dump($auth);
            }
			//$userId = App\User::all();
			
			/*foreach($userId as $ud){
				if($userData['username'] == $ud->username && $userData['password'] == $ud->password){
					echo $ud->username;
					break;
				}
				else{
					return redirect('login')->withErrors($validator, 'login');
				}
			}*/
		}	
	}
}