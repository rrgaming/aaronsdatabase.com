<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
	<div class="panel-heading">
		<h2>Login</h2>
	</div>
    <div class="panel-body">
        <?php echo e(Form::open(array('url' => 'login'))); ?>

		
		<!-- if there are login errors, show them here -->

		<p>
		    <?php echo e($errors->first('username')); ?>

		    <?php echo e($errors->first('password')); ?>

		</p>

		<div class="form-group">
		    <?php echo e(Form::label('username', 'Username')); ?>

		    <?php echo e(Form::text('username','',array('placeholder' => 'Username', 'class' => 'form-control'))); ?>

		</div>

		<div class="form-group">
		    <?php echo e(Form::label('password', 'Password')); ?>

		    <input type="password" name="password" class="form-control" placeholder="Password">
		</div>

		<p>
			<?php echo e(Form::submit('Submit',['class' => 'btn btn-large btn-primary'])); ?>

			<?php echo e(Html::link('register', 'Not yet User?')); ?>

		</p>
		<?php echo e(Form::close()); ?>

    </div>
</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>