<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
	<div class="panel-heading">
		<h2>Register</h2>
	</div>
    <div class="panel-body">
    	<?php echo e(Form::open(array('url' => 'register'))); ?>


		<!-- if there are login errors, show them here -->

		<p>
		    <?php echo e($errors->first('username')); ?>

		    <?php echo e($errors->first('password')); ?>

		</p>
		<div class="form-group">
			<?php echo e(Form::label('username', 'Username')); ?>

		    <?php echo e(Form::email('username', Input::old('text'), array('placeholder' => 'Username', 'class' => 'form-control'))); ?>

		</div>
		 <div class="form-group">
		 	<?php echo e(Form::label('email', 'Email Address')); ?>

		    <?php echo e(Form::text('email', Input::old('email'), array('placeholder' => 'Email', 'class' => 'form-control'))); ?>

		 </div>   
		    

		<div class="form-group">
		    <?php echo e(Form::label('password', 'Password')); ?>

		    <input type="password" name="password" class="form-control" placeholder="Password">
		</div>

		<p>
			<?php echo e(Form::submit('Register',['class' => 'btn btn-large btn-primary'])); ?>

			<?php echo e(Html::link('login', 'Cancel', array('class' => 'btn btn-danger'))); ?>

		</p>
		<?php echo e(Form::close()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>