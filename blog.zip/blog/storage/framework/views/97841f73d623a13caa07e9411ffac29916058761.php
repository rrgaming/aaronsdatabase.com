<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($dt->fname); ?>

	<?php echo e($dt->lname); ?>

	<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>